package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.data.model.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = ZapEmeraldPrimaryDark,
    onPrimary = ZapOnEmeraldDark,
    primaryContainer = ZapEmeraldContainerDark,
    onPrimaryContainer = ZapOnEmeraldContainerDark,
    secondary = ZapTealSecondaryDark,
    onSecondary = ZapOnTealSecondaryDark,
    secondaryContainer = ZapTealContainerDark,
    onSecondaryContainer = ZapOnTealContainerDark,
    tertiary = ZapCyanTertiaryDark,
    onTertiary = ZapOnCyanTertiaryDark,
    tertiaryContainer = ZapCyanContainerDark,
    onTertiaryContainer = ZapOnCyanContainerDark,
    background = ZapBackgroundDark,
    surface = ZapSurfaceDark,
    surfaceVariant = ZapSurfaceVariantDark,
    onSurface = ZapOnSurfaceDark,
    onSurfaceVariant = ZapOnSurfaceVariantDark
)

private val LightColorScheme = lightColorScheme(
    primary = ZapEmeraldPrimaryLight,
    onPrimary = ZapOnEmeraldLight,
    primaryContainer = ZapEmeraldContainerLight,
    onPrimaryContainer = ZapOnEmeraldContainerLight,
    secondary = ZapTealSecondaryLight,
    onSecondary = ZapOnTealSecondaryLight,
    secondaryContainer = ZapTealContainerLight,
    onSecondaryContainer = ZapOnTealContainerLight,
    tertiary = ZapCyanTertiaryLight,
    onTertiary = ZapOnCyanTertiaryLight,
    tertiaryContainer = ZapCyanContainerLight,
    onTertiaryContainer = ZapOnCyanContainerLight,
    background = ZapBackgroundLight,
    surface = ZapSurfaceLight,
    surfaceVariant = ZapSurfaceVariantLight,
    onSurface = ZapOnSurfaceLight,
    onSurfaceVariant = ZapOnSurfaceVariantLight
)

@Composable
fun Zap2Theme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Zap2Typography,
        shapes = Zap2Shapes,
        content = content
    )
}
