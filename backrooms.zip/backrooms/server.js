const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static('public'));

let rooms = {};

wss.on('connection', (ws) => {
    console.log("👤 Jogador conectado");

    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);

            switch(data.type) {
                case "create-room":
                    const roomCode = Math.random().toString(36).substring(2,8).toUpperCase();
                    rooms[roomCode] = { players: [{id: data.playerId, ws}] };
                    
                    ws.send(JSON.stringify({
                        type: "room-created",
                        roomCode,
                        players: rooms[roomCode].players.map(p => ({id: p.id}))
                    }));
                    break;

                case "join-room":
                    if (rooms[data.roomCode]) {
                        rooms[data.roomCode].players.push({id: data.playerId, ws});
                        broadcastToRoom(data.roomCode, {
                            type: "room-joined",
                            roomCode: data.roomCode,
                            players: rooms[data.roomCode].players.map(p => ({id: p.id}))
                        });
                    } else {
                        ws.send(JSON.stringify({type: "error", message: "Sala não encontrada"}));
                    }
                    break;

                case "update-position":
                case "chat":
                case "player-died":
                case "level-complete":
                case "start-game":
                    broadcastToRoom(data.roomCode, {
                        ...data,
                        playerId: data.playerId
                    }, data.playerId);
                    break;
            }
        } catch(e) {}
    });

    ws.on('close', () => console.log("👤 Jogador desconectado"));
});

function broadcastToRoom(roomCode, message, excludeId = null) {
    if (!rooms[roomCode]) return;
    rooms[roomCode].players.forEach(p => {
        if (p.id !== excludeId && p.ws.readyState === WebSocket.OPEN) {
            p.ws.send(JSON.stringify(message));
        }
    });
}

// A parte final deve ficar EXATAMENTE assim:
server.listen(3000, '0.0.0.0', () => {
    console.log("🚀 Servidor rodando em http://0.0.0.0:3000");
});
